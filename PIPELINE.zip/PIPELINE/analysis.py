import configparser
config = configparser.ConfigParser()
import mdtraj as md
import numpy as np
from scipy.spatial.distance import squareform
import scipy.cluster.hierarchy as hy
import multiprocessing as mp
from functools import partial
from scipy.stats import entropy
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
from scipy.sparse.linalg import eigs
from scipy.stats import pearsonr
from sklearn.metrics import rand_score, adjusted_rand_score, normalized_mutual_info_score, adjusted_mutual_info_score
import matplotlib.colors as mcolors
import mdtraj as md
import MDAnalysis as mda
from MDAnalysis.analysis.align import AlignTraj
from MDAnalysis.coordinates.XTC import XTCWriter
from MDAnalysis.analysis.pca import PCA


def DMAPS(data, eps, name='h' ,save=False, norm='lb',show_plot=False):
    ''' DMaps calculation '''

    # La funzione inizia con il calcolo della matrice di similarità utilizzando le distanze tra le diverse conformazioni della proteina.
    dist_sq = np.square( data )   # Eleva al quadrato i dati in input
    W = np.exp( - dist_sq / eps ** 2 )   # Calcola la matrice di peso costruita utilizzando una funzione gaussiana che esprime la similarità tra i punti
                                         #  Il parametro eps (epsilon) controlla la "scala" della funzione gaussiana,
                                         #  ossia quanto velocemente la similarità decresce all'aumentare della distanza tra i punti.
    ''' Normalization '''

    NORM=norm

    if NORM == 'stoch':
        # normalization array, ith element is the sum of the ith row of matrix K
        NRM = W.sum( axis=1 ) 
        NRM = np.diag( NRM )
        NRM = np.linalg.inv( NRM )
        # D is the correctly normalized diffusion matrix
        D = np.dot( NRM, W )

    else:
        ''' Laplace-Beltrami density invariant normalization -- From Elio's code '''
        sW = np.sum( W, axis=0 ) # sum over all columns, should be the same, W is symm.
        W = W / np.sqrt( np.dot( sW, sW ) )
        sW = np.sum( W, axis=1 )
        NRM = np.diag( sW )
        NRM = np.linalg.inv( NRM )
        D = np.dot( NRM, W )

# NOW WE HAVE THE DIFFUSION MATRIX D

    # returns k largest eigenvaules/vectors
    evals1, evecs1 = eigs(A=D, k=5, which='LM')
    #evals1, evecs1 = np.linalg.eig(a=D)
    
    if show_plot:
        plt.plot( evals1, 'o' )
        plt.xlim(-0.1, 9.5)
        plt.ylim(0, 1.1)
        plt.grid(True)
        plt.title('Sorted Dmaps eigenvalues')
        plt.ylabel('Eigenvalue')
        plt.xlabel('Index')
        if save:
            plt.savefig(name+'.png', bbox_inches='tight',pad_inches = 0)
        plt.show()
    
    return [evals1, evecs1]

def calculate_entropies(k):
    """Calculate resolution and relevance from clustering."""
    # resolution
    hs = entropy(k)
    # relevance
    ks = np.unique(k, return_counts=True)
    pk = np.multiply(ks[0], ks[1])
    hk = entropy(pk)
    
    return hs, hk

def cut_and_compute(Z, n):
    """Cut the dendrogram Z in n clusters following maxclust criterion and calculate entropy"""
    cl_labels = hy.fcluster(Z, t=n, criterion='maxclust')
    k=[(cl_labels==t).sum() for t in set(cl_labels)]
       
    res, rel=calculate_entropies(k)
       
    return [res, rel]

def retrive_labels(Z, resrel):
    """Retrive the label vectors corresponding to the maximal resolution"""
    
    Nclu_max = int (np.argmax(resrel[:,1])*10+1)
    label= hy.fcluster(Z, t=Nclu_max, criterion='maxclust')
    
    return label

def ResRel(distance_matrix):
 
    dist=distance_matrix
    dist_max=dist[dist!=np.inf].max()

    sdist=squareform(dist/dist_max, checks=False)

    M=int((1+np.sqrt(1+8*sdist.shape[0]))/2) 
    Nclu=range(1,M,10) 
    
       
    ## Compute the dendrogram
    Z = hy.linkage(sdist,'average')
    
    ## start the computation in parallel
    
    pool = mp.Pool(10)
    temp = partial( cut_and_compute , Z )
    result = pool.map ( func = temp , iterable = Nclu )
    pool.close()
    pool.join()

    label = retrive_labels(Z, np.array(result))

    return np.array(result), label, M

def calculate_centroid(cluster_indices, dist_matrix):
    # Select rows of the RMSD matrix
    sub_matrix = dist_matrix[cluster_indices]
    # Compute the controid (mean of the row)
    centroid = sub_matrix.mean(axis=0)
    return centroid

def Cluster_Distance(label_vector, rmsd_matrix, method='average'):
    num_clusters = np.max(label_vector)
    distance_matrix = np.zeros((num_clusters, num_clusters))

    for i in range(1, num_clusters + 1):
        for j in range(i, num_clusters + 1):
            # Find indeces of configurations in cluster i and j
            cluster_i_indices = np.where(label_vector == i)[0]
            cluster_j_indices = np.where(label_vector == j)[0]

            if i != j:
                if method == 'single':
                    # Single linkage: minimum distance between cluster members
                    distance = rmsd_matrix[np.ix_(cluster_i_indices, cluster_j_indices)].min()
                elif method == 'complete':
                    # Complete linkage: maximum distance between cluster members
                    distance = rmsd_matrix[np.ix_(cluster_i_indices, cluster_j_indices)].max()
                elif method == 'average':
                    # Average linkage: avarage distance between cluster members
                    distance = rmsd_matrix[np.ix_(cluster_i_indices, cluster_j_indices)].mean()
                elif method == 'centroid':
                    # Centroid linkage: distance between cluster centroids
                    centroid_i = calculate_centroid(cluster_i_indices, rmsd_matrix)
                    centroid_j = calculate_centroid(cluster_j_indices, rmsd_matrix)
                    distance = np.linalg.norm(centroid_i - centroid_j)
                elif method == 'ward':
                    # Ward linkage: minimize total variance
                    centroid_i = calculate_centroid(cluster_i_indices, rmsd_matrix)
                    centroid_j = calculate_centroid(cluster_j_indices, rmsd_matrix)
                    distance = np.sum((centroid_i - centroid_j) ** 2)
            else:
                distance = 0  # Distance between a cluster and itself is zero

            # Load the distance matrix
            distance_matrix[i - 1, j - 1] = distance
            distance_matrix[j - 1, i - 1] = distance 

    return distance_matrix

def uniform_striding(matrix, n):

    if(n==1): return matrix

    selected_indices = np.arange(0, matrix.shape[0], n)
    selected_indices = selected_indices[:-1]
    mat = matrix[selected_indices, :][:, selected_indices]
    return mat

def random_striding(matrix, n):

    if(n==1): return matrix

    N = matrix.shape[0]
    num_indices = N // n
    selected_indices = np.sort(np.random.choice(N, num_indices, replace=False))
    mat = matrix[selected_indices, :][:, selected_indices]
    return mat

def intercov(t_coarse,loci):
    M=t_coarse.n_frames
    ## the average position of each atom in the trajectory on the whole trajectory
    mean=t_coarse.xyz.mean(axis=0) 
    ## the average position of each atom in the trajectori on the frame pertaining to each cluster.
    mean_intra=np.array([t_coarse.slice(i).xyz.mean(axis=0) for i in loci])
    
    #compute the difference
    diff_mean=mean_intra-mean
    
    #compute the covariance (in each direction)
    cov_inter_x=np.sum([np.outer(diff_mean[i,:,0],diff_mean[i,:,0])*len(loci[i]) for i in range(0,len(loci))],axis=0)/M
    cov_inter_y=np.sum([np.outer(diff_mean[i,:,1],diff_mean[i,:,1])*len(loci[i]) for i in range(0,len(loci))],axis=0)/M
    cov_inter_z=np.sum([np.outer(diff_mean[i,:,2],diff_mean[i,:,2])*len(loci[i]) for i in range(0,len(loci))],axis=0)/M
    return cov_inter_x+cov_inter_y+cov_inter_z

def intracov(t, sl):
    
    M=t.n_frames
    x=t.slice(sl).xyz[:,:,0]
    y=t.slice(sl).xyz[:,:,1]
    z=t.slice(sl).xyz[:,:,2]

    if len(sl)>1:
        cov=np.cov(x.T)+np.cov(y.T)+np.cov(z.T)
    else:
        cov=np.zeros((x.shape[1],x.shape[1])) 
    return cov*len(sl)/M

def Traj_builder(distance,label_vector,save_path,name):

    # FIND CLUSTERS REPRESENTATIVE FRAMES ---> CLOSEST FRAME TO THE CLUSTER CENTROID

    unique_clusters = np.unique(label_vector)
    representative_frames = {}

    for cluster in unique_clusters:
        cluster_indices = np.where(label_vector == cluster)[0]
        centroid = calculate_centroid(cluster_indices, distance)
        closest_frame = cluster_indices[np.argmin(np.linalg.norm(distance[cluster_indices] - centroid, axis=1))]
        representative_frames[cluster] = closest_frame

    # CREATE THE NEW TRAJECTORY
    new_coordinates = []

    for frame_index in range(len(label_vector)):
        cluster = label_vector[frame_index]
        representative_frame = representative_frames[cluster]
        u.trajectory[representative_frame]  # Move to representative frame
        new_coordinates.append(u.trajectory.ts.positions.copy())  # Copy coordinates

    # Convert in 3D array (n_frames x n_atoms x 3)
    new_coordinates_array = np.array(new_coordinates)

    new_universe = mda.Universe(input_gro)  # use original topology
    new_universe.load_new(new_coordinates_array)  # load new coordinates

    ref = mda.Universe(input_gro)  # use original topology
    ref.load_new(new_coordinates_array)  # load new coordinates

    aligner = AlignTraj(new_universe,ref,select='name CA')
    aligner.run()

    # Percorso di salvataggio
    output_filename = save_path+f"/PCA/Traj/{name}.xtc"

    # Usa un writer per scrivere senza dimensioni della cella unitaria
    with XTCWriter(output_filename, n_atoms=new_universe.atoms.n_atoms) as writer:
        for ts in new_universe.trajectory:
            writer.write(new_universe.atoms)





config.read('par_dist.dat')

input_gro = config['DEFAULT']['frame']
input_xtc = config['DEFAULT']['traj']
sel = config['DEFAULT']['selection']
metrics = config['DEFAULT']['metrics'].split(', ')
strides_names = config['DEFAULT']['strides'].split(', ')

print()
print('------------------------------- START -------------------------------')
print()

if sel == 'name CA':
    save_path = 'save_and_load/C_A'
if sel == 'all':
    save_path = 'save_and_load/AA'

u = mda.Universe(input_gro, input_xtc)


distances = []

for met in metrics:
    mat = np.load(save_path+f'/distances/{met}.npy')
    distances.append(mat)

strides = [int(num) for num in strides_names]


############################################### RUN RESOLUTION AND RELEVANCE ###############################################

ResRel_UNI = []
labels_UNI = []

ResRel_RAND = []
labels_RAND = []

M = []

for stri in strides:

    UNI_Resrel_stri = []
    RAND_Resrel_stri = []
    UNI_label_stri = []
    RAND_label_stri = []

    for met in distances:

        UNI_matrix = uniform_striding(met,int(stri))
        RAND_matrix = random_striding(met,int(stri))

        UNI_resrel_curve, UNI_label, m = ResRel(UNI_matrix)
        RAND_resrel_curve, RAND_label, m = ResRel(RAND_matrix)

        UNI_Resrel_stri.append(UNI_resrel_curve)
        UNI_label_stri.append(UNI_label)
        RAND_Resrel_stri.append(RAND_resrel_curve)
        RAND_label_stri.append(RAND_label)

    ResRel_UNI.append(UNI_Resrel_stri)
    labels_UNI.append(UNI_label_stri)
    ResRel_RAND.append(RAND_Resrel_stri)
    labels_RAND.append(RAND_label_stri)
    M.append(m)

with open(save_path+'/ResRel/ResRel_UNI.pkl', 'wb') as file:
    pickle.dump(ResRel_UNI, file)

with open(save_path+'/ResRel/labels_UNI.pkl', 'wb') as file:
    pickle.dump(labels_UNI, file)

with open(save_path+'/ResRel/ResRel_RAND.pkl', 'wb') as file:
    pickle.dump(ResRel_RAND, file)

with open(save_path+'/ResRel/labels_RAND.pkl', 'wb') as file:
    pickle.dump(labels_RAND, file)

with open(save_path+'/ResRel/M.pkl', 'wb') as file:
    pickle.dump(M, file)


############################################### COMPUTE INTER/INTRA- CLUSTER COV MATRICES TRACES ###############################################


INTER_random = []
INTRA_random = []
INTER_uniform = []
INTRA_uniform = []

for i in range(len(metrics)):

    INTER_values = []
    INTRA_values = []

    for j in range(len(strides)):

        t = md.load(input_xtc,top=input_gro,stride= strides[j],discard_overlapping_frames=True)
        t_coarse=t.atom_slice(atom_indices= t.top.select(sel))
        t_coarse.superpose(t_coarse,frame=t.n_frames-1)
        lab = labels_RAND[j][i]
        loci = [np.where(lab == cluster)[0] for cluster in set(lab)]
        Inter = np.trace(intercov(t_coarse,loci))
        Intra = np.trace(np.sum([intracov(t_coarse,llc) for llc in loci],axis=0))

        INTER_values.append(Inter)
        INTRA_values.append(Intra)

  
    INTER_random.append(INTER_values)
    INTRA_random.append(INTRA_values)

with open(save_path+'/COV_MAT/INTER_random.pkl', 'wb') as file:
    pickle.dump(INTER_random, file)

with open(save_path+'/COV_MAT/INTRA_random.pkl', 'wb') as file:
    pickle.dump(INTRA_random, file)


for i in range(len(metrics)):

    INTER_values = []
    INTRA_values = []

    for j in range(len(strides)):

        t = md.load(input_xtc,top=input_gro,stride= strides[j],discard_overlapping_frames=True)
        t_coarse=t.atom_slice(atom_indices= t.top.select(sel))
        t_coarse.superpose(t_coarse,frame=t.n_frames-1)
        lab = labels_UNI[j][i]
        loci = [np.where(lab == cluster)[0] for cluster in set(lab)]
        Inter = np.trace(intercov(t_coarse,loci))
        Intra = np.trace(np.sum([intracov(t_coarse,llc) for llc in loci],axis=0))

        INTER_values.append(Inter)
        INTRA_values.append(Intra)

  
    INTER_uniform.append(INTER_values)
    INTRA_uniform.append(INTRA_values)

with open(save_path+'/COV_MAT/INTER_uniform.pkl', 'wb') as file:
    pickle.dump(INTER_uniform, file)

with open(save_path+'/COV_MAT/INTRA_uniform.pkl', 'wb') as file:
    pickle.dump(INTRA_uniform, file)



############################################### COMPUTE DIFFUSION MAPS ###############################################

HR_DC1 = []
HR_DC2 = []
LR_DC1 = []
LR_DC2 = []

for i in range(len(metrics)):

    HR_distance = distances[i]
    np.fill_diagonal(HR_distance,0.0)
    LR_distance = Cluster_Distance(labels_UNI[0][i], HR_distance, method='average')

    evals_HR, evecs_HR = DMAPS(data=HR_distance, eps=np.quantile(squareform(HR_distance),0.1), norm='lb',show_plot=False)
    evals_LR, evecs_LR = DMAPS(data=LR_distance, eps=np.quantile(squareform(LR_distance),0.1), norm='lb',show_plot=False)


    evals_HR = np.real(evals_HR)
    evecs_HR = np.real(evecs_HR)
    evals_LR = np.real(evals_LR)
    evecs_LR = np.real(evecs_LR)
    sorted_indices = np.argsort(evals_HR)[::-1]
    evecs_HR = evecs_HR[:, sorted_indices]
    sorted_indices = np.argsort(evals_LR)[::-1]
    evecs_LR = evecs_LR[:, sorted_indices]

    temp_HR_DC1 = evals_HR[1] * evecs_HR[:,1]/np.abs(evals_HR[1] * evecs_HR[:,1]).max()
    temp_HR_DC2 = evals_HR[2] * evecs_HR[:,2]/np.abs(evals_HR[2] * evecs_HR[:,2]).max()
    temp_LR_DC1 = evals_LR[1] * evecs_LR[:,1]/np.abs(evals_LR[1] * evecs_LR[:,1]).max()
    temp_LR_DC2 = evals_LR[2] * evecs_LR[:,2]/np.abs(evals_LR[2] * evecs_LR[:,2]).max()

    HR_DC1.append(temp_HR_DC1)
    HR_DC2.append(temp_HR_DC2)
    LR_DC1.append(temp_LR_DC1)
    LR_DC2.append(temp_LR_DC2)

with open(save_path+'/DMAPS/HR_DC1.pkl', 'wb') as file:
    pickle.dump(HR_DC1, file)

with open(save_path+'/DMAPS/HR_DC2.pkl', 'wb') as file:
    pickle.dump(HR_DC2, file)

with open(save_path+'/DMAPS/LR_DC1.pkl', 'wb') as file:
    pickle.dump(LR_DC1, file)

with open(save_path+'/DMAPS/LR_DC2.pkl', 'wb') as file:
    pickle.dump(LR_DC2, file)




############################################### PCA ###############################################

u = mda.Universe(input_gro, input_xtc)

for i in range(len(metrics)):
    Traj_builder(distances[i], labels_UNI[0][i], save_path, metrics[i])


u = mda.Universe(input_gro, input_xtc)
pca = PCA(u, select=sel)
pca.run()
red_space = pca.transform(u.select_atoms('name CA'), 10)
red_space_normalized = red_space / np.linalg.norm(red_space, axis=0)
np.save(save_path+f'/PCA/PCs_full_traj.npy', red_space_normalized)

for met in metrics:

    u = mda.Universe(input_gro, save_path+f"/PCA/Traj/{met}.xtc")
    pca = PCA(u, select='name CA')
    pca.run()
    red_space = pca.transform(u.select_atoms('name CA'))
    red_space_normalized = red_space / np.linalg.norm(red_space, axis=0)
    np.save(save_path+f'/PCA/PCs_{met}.npy', red_space_normalized)
