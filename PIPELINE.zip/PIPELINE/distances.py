import numpy as np
import MDAnalysis as mda
from MDAnalysis.analysis import align
from MDAnalysis.lib import distances
from scipy.spatial.distance import hamming, jaccard, cosine
import configparser
from scipy.spatial.distance import squareform
from joblib import Parallel, delayed



def compute_wrmsd(u, ref, sel, weights, i, j):
    ref.trajectory[i]
    reference_atoms = ref.select_atoms(sel)
    u.trajectory[j]
    mobile_atoms = u.select_atoms(sel)
    align.alignto(mobile_atoms, reference_atoms, weights=weights)
    diff = mobile_atoms.positions - reference_atoms.positions
    weighted_square_diff = np.sum(weights * np.sum(diff ** 2, axis=1))
    return np.sqrt(weighted_square_diff / np.sum(weights))

def wrmsd(u, sel, n_jobs=-1):
    ref = u.copy()
    n_frames = u.trajectory.n_frames
    dist_matrix = np.zeros((n_frames, n_frames))
    weights = u.select_atoms(sel).masses

    # Generate all unique pairs (i, j) with i <= j
    frame_pairs = [(i, j) for i in range(n_frames) for j in range(i, n_frames)]

    # Compute WRMSD for each pair in parallel
    wrmsd_values = Parallel(n_jobs=n_jobs)(
        delayed(compute_wrmsd)(u, ref, sel, weights, i, j) for i, j in frame_pairs
    )

    # Fill the distance matrix
    for k, (i, j) in enumerate(frame_pairs):
        dist_matrix[i, j] = wrmsd_values[k]
        dist_matrix[j, i] = wrmsd_values[k]

    return dist_matrix
    

def compute_rmsd_L1(u, ref, sel, weights, i, j):
    ref.trajectory[i]
    reference_atoms = ref.select_atoms(sel)
    u.trajectory[j]
    mobile_atoms = u.select_atoms(sel)
    align.alignto(mobile_atoms, reference_atoms, weights=weights)
    L1_distances = np.sum(np.abs(mobile_atoms.positions - reference_atoms.positions), axis=1)
    msd = np.mean(L1_distances**2)
    return np.sqrt(msd)

def rmsd_L1(u, sel, n_jobs=-1):
    ref = u.copy()
    n_frames = u.trajectory.n_frames
    dist_matrix = np.zeros((n_frames, n_frames))
    weights = u.select_atoms(sel).masses

    # Generate all unique pairs (i, j) with i <= j
    frame_pairs = [(i, j) for i in range(n_frames) for j in range(i, n_frames)]

    # Compute RMSD for each pair in parallel
    rmsd_values = Parallel(n_jobs=n_jobs)(
        delayed(compute_rmsd_L1)(u, ref, sel, weights, i, j) for i, j in frame_pairs
    )

    # Fill the distance matrix
    for k, (i, j) in enumerate(frame_pairs):
        dist_matrix[i, j] = rmsd_values[k]
        dist_matrix[j, i] = rmsd_values[k]

    return dist_matrix


def compute_rmsd_L2(u, ref, sel, weights, i, j):
    ref.trajectory[i]
    reference_atoms = ref.select_atoms(sel)
    u.trajectory[j]
    mobile_atoms = u.select_atoms(sel)
    align.alignto(mobile_atoms, reference_atoms, weights=weights)
    diff = mobile_atoms.positions - reference_atoms.positions
    return np.sqrt(np.mean(np.sum(diff**2, axis=1)))

def rmsd_L2(u, sel, n_jobs=-1):
    ref = u.copy()
    n_frames = u.trajectory.n_frames
    dist_matrix = np.zeros((n_frames, n_frames))
    weights = u.select_atoms(sel).masses

    # Generate all unique pairs (i, j) with i <= j
    frame_pairs = [(i, j) for i in range(n_frames) for j in range(i, n_frames)]

    # Compute RMSD for each pair in parallel
    rmsd_values = Parallel(n_jobs=n_jobs)(
        delayed(compute_rmsd_L2)(u, ref, sel, weights, i, j) for i, j in frame_pairs
    )

    # Fill the distance matrix
    for k, (i, j) in enumerate(frame_pairs):
        dist_matrix[i, j] = rmsd_values[k]
        dist_matrix[j, i] = rmsd_values[k]

    return dist_matrix


def compute_rmsd_Linf(u, ref, sel, weights, i, j):
    ref.trajectory[i]
    reference_atoms = ref.select_atoms(sel)
    u.trajectory[j]
    mobile_atoms = u.select_atoms(sel)
    align.alignto(mobile_atoms, reference_atoms, weights=weights)
    Linf_distances = np.max(np.abs(mobile_atoms.positions - reference_atoms.positions), axis=1)
    MSD = np.mean(Linf_distances**2)
    return np.sqrt(MSD)

def rmsd_Linf(u, sel, n_jobs=-1):
    ref = u.copy()
    n_frames = u.trajectory.n_frames
    dist_matrix = np.zeros((n_frames, n_frames))
    weights = u.select_atoms(sel).masses

    # Generate all unique pairs (i, j) with i <= j
    frame_pairs = [(i, j) for i in range(n_frames) for j in range(i, n_frames)]

    # Compute RMSD for each pair in parallel
    rmsd_values = Parallel(n_jobs=n_jobs)(
        delayed(compute_rmsd_Linf)(u, ref, sel, weights, i, j) for i, j in frame_pairs
    )

    # Fill the distance matrix
    for k, (i, j) in enumerate(frame_pairs):
        dist_matrix[i, j] = rmsd_values[k]
        dist_matrix[j, i] = rmsd_values[k]

    return dist_matrix
    


def Rgyr(u, sel):        
    
    Rgyr = []
    for ts in u.trajectory:
        Rgyr.append(u.select_atoms(sel).radius_of_gyration())

    n_frames = u.trajectory.n_frames
    dist_matrix = np.zeros((n_frames, n_frames))
    for i in range(n_frames):
        for j in range(n_frames):
            dist_matrix[i, j] = abs(Rgyr[i] - Rgyr[j])

    return dist_matrix



def compute_row(u,i,sel):
    N_frames = u.trajectory.n_frames
    u.trajectory[i]  # Move to frame i
    atom_selection = u.select_atoms(sel)
    dist_map_1 = distances.distance_array(atom_selection.positions, atom_selection.positions)
    binary_map_1 = np.where(dist_map_1 < 8, 1, 0)

    hamm_row = []  
    jac_row = []   
    cos_row = []   

    for j in range(i + 1, N_frames):
        u.trajectory[j]  # Move to frame j
        dist_map_2 = distances.distance_array(atom_selection.positions, atom_selection.positions)
        binary_map_2 = np.where(dist_map_2 < 8, 1, 0)

        # Calculate distances
        hamm_row.append(hamming(binary_map_1.flatten(), binary_map_2.flatten()))
        jac_row.append(jaccard(binary_map_1.flatten(), binary_map_2.flatten()))
        cos_row.append(cosine(binary_map_1.flatten(), binary_map_2.flatten()))

    return i, hamm_row, jac_row, cos_row

def CMAP(u, sel, name_list, cores, save_path, output_name):

    N_frames = u.trajectory.n_frames
    results = Parallel(n_jobs=cores)(delayed(compute_row)(u,i,sel) for i in range(N_frames))

    HAMM = np.array([])
    JAC = np.array([])
    COS = np.array([])

    for i, hamm_row, jac_row, cos_row in results:
        HAMM = np.hstack((HAMM, hamm_row))
        JAC = np.hstack((JAC, jac_row))
        COS = np.hstack((COS, cos_row))
    
    if 'CMAP_H' in name_list:
        np.save(save_path+output_name+f'_CMAP_H.npy',squareform(HAMM))
        
    if 'CMAP_J' in name_list:
        np.save(save_path+output_name+f'_CMAP_J.npy',squareform(JAC))
        
    if 'CMAP_cos' in name_list:
        np.save(save_path+output_name+f'_CMAP_cos.npy',squareform(COS))


#-----------------------------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------

config = configparser.ConfigParser()
config.read('par_dist.dat')

metrics_dict = {
    'wrmsd': wrmsd,
    'rmsd_L1': rmsd_L1,
    'rmsd_L2': rmsd_L2,
    'rmsd_Linf': rmsd_Linf,
    'Rgyr' : Rgyr,
    'CMAP_H':None,
    'CMAP_J':None,
    'CMAP_cos':None
}

input_gro = config['DEFAULT']['frame']
input_xtc = config['DEFAULT']['traj']
sel = config['DEFAULT']['selection']
metrics_names = config['DEFAULT']['metrics'].split(', ')
cores = int(config['DEFAULT']['cores'])
output_name = config['DEFAULT']['output_name']

print()
print('------------------------------- START -------------------------------')
print()

unexpected_metrics = [name for name in metrics_names if name not in metrics_dict]
if unexpected_metrics:
    print(f"Error: The following metrics are not implemented: {', '.join(unexpected_metrics)}")
    print()
    print(f"The implemented metrics are: {', '.join(metrics_dict.keys())}")
    print()
    exit(1) 

print('METRICS CORRECTLY LOADED')
print()

u = mda.Universe(input_gro, input_xtc)

if sel == 'name CA':
    save_path = 'save_and_load/C_A/distances/'
if sel == 'all':
    save_path = 'save_and_load/AA/distances/'


print('SAVE PATH CORRECTLY LOADED')
print()


standard_metrics = ['wrmsd', 'rmsd_L1', 'rmsd_L2', 'rmsd_Linf', 'Rgyr']
cmap_metrics = ['CMAP_H', 'CMAP_J', 'CMAP_cos']

standard_metrics_selected = [met for met in metrics_names if met in standard_metrics]
cmap_metrics_selected = [met for met in metrics_names if met in cmap_metrics]


for met_name in standard_metrics_selected:

    met_func = metrics_dict[met_name]
    dist_mat = met_func(u, sel, cores)
    np.save(save_path+output_name+f'_{met_func.__name__}.npy', dist_mat)
        

if len(cmap_metrics_selected)>0: 
    CMAP(u,sel,cmap_metrics_selected,cores,save_path,output_name)
    
